//
//  RNCAppDelegate.m
//  ReactNativeCore
//
//  Created by Liam Xu on 03/26/2021.
//  Copyright (c) 2021 Liam Xu. All rights reserved.
//

#import "RNCAppDelegate.h"
#import "RNCViewController.h"
#import <QCloudCOSXML/QCloudCOSXML.h>
#import <SSZipArchive/SSZipArchive.h>

@interface RNCAppDelegate () <QCloudSignatureProvider>
#if __has_include(<UMModuleRegistryAdapter.h>)
@property (nonatomic, strong) UMModuleRegistryAdapter *moduleRegistryAdapter;
#endif
@end

@implementation RNCAppDelegate

- (void)updateFramework:(NSString *)name finishBlock:(void (^)(NSString *name))finishBlock {
    QCloudCOSXMLDownloadObjectRequest *request = [QCloudCOSXMLDownloadObjectRequest new];
    // 存储桶名称，格式为 BucketName-APPID
    request.bucket = @"beat-rn-framework-1252250461";
    // 对象键，是对象在 COS 上的完整路径，如果带目录的话，格式为 "video/xxx/movie.mp4"
    NSString *frameworkName = [name stringByAppendingString:@".xcframework"];
    NSString *frameworkZipName = [frameworkName stringByAppendingString:@".zip"];
    request.object = frameworkZipName;
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docDir = paths.firstObject;
    //设置下载的路径 URL，如果设置了，文件将会被下载到指定路径中
    NSString *fileDir = [docDir stringByAppendingPathComponent:frameworkZipName];
    request.downloadingURL = [NSURL fileURLWithPath:fileDir];
    //监听下载结果
    [request setFinishBlock:^(id outputObject, NSError *error) {
      //outputObject 包含所有的响应 http 头部
        NSDictionary *info = (NSDictionary *) outputObject;
        NSLog(@"解压成功");
        NSString *sourceFilePath = fileDir;
        //目的文件路径
        NSString *destinationPath = docDir;
        //把 sourceFilePath 这个路径下的zip包，解压到这个 destinationPath 路径下
        if ([SSZipArchive unzipFileAtPath:sourceFilePath toDestination:destinationPath]) {
            NSLog(@"解压成功");
            NSString *frameworkDir = [destinationPath stringByAppendingPathComponent:frameworkName];
            NSBundle *frameworkBundle = [NSBundle bundleWithPath:[frameworkDir stringByAppendingFormat:@"/ios-arm64_armv7/%@.framework", name]];
//            NSBundle *frameworkBundle = [NSBundle bundleWithPath:[frameworkDir stringByAppendingFormat:@"/ios-arm64_i386_x86_64-simulator/%@.framework", name]];
            if (frameworkBundle && [frameworkBundle load]) {
                NSLog(@"bundle load framework success.");
                finishBlock(name);
            }
        } else {
            NSLog(@"解压失败");
        }
        
    }];
    //监听下载进度
    [request setDownProcessBlock:^(int64_t bytesDownload,
                                  int64_t totalBytesDownload,
                                  int64_t totalBytesExpectedToDownload) {
        NSLog(@"bytesDownload=%lld/ntotalBytesDownload=%lld/ntotalBytesExpectedToDownload=%lld",
              bytesDownload,
              totalBytesDownload,
              totalBytesExpectedToDownload);
    }];
    [[QCloudCOSTransferMangerService defaultCOSTransferManager] DownloadObject:request];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    QCloudServiceConfiguration *configuration = [QCloudServiceConfiguration new];
    QCloudCOSXMLEndPoint *endpoint = [[QCloudCOSXMLEndPoint alloc] init];
    // 服务地域简称，例如广州地域是 ap-guangzhou
    endpoint.regionName = @"ap-guangzhou";
    // 使用 HTTPS
    endpoint.useHTTPS = true;
    configuration.endpoint = endpoint;
    // 密钥提供者为自己
    configuration.signatureProvider = self;
    // 初始化 COS 服务示例
    [QCloudCOSXMLService registerDefaultCOSXMLWithConfiguration:configuration];
    [QCloudCOSTransferMangerService registerDefaultCOSTransferMangerWithConfiguration:
     configuration];
    // Override point for customization after application launch.
#if __has_include(<UMModuleRegistryAdapter.h>)
    self.moduleRegistryAdapter = [[UMModuleRegistryAdapter alloc] initWithModuleRegistryProvider:[[UMModuleRegistryProvider alloc] init]];
#endif
    
    RCTBridge *bridge = [[RCTBridge alloc] initWithDelegate:self launchOptions:launchOptions];
#if __has_include(<UMModuleRegistryAdapter.h>)
    RCTRootView *rootView = [[RCTRootView alloc]
                             initWithBridge:bridge
                             moduleName:@"main"
                             initialProperties:nil];
#else
    RCTRootView *rootView = [[RCTRootView alloc] initWithBridge:bridge
                                                     moduleName:@"AwesomeProject"
                                              initialProperties:nil];
#endif
    NSArray *frameworkNames = @[
        @"RCTText",
//        @"RCTAnimation",
//        @"RCTBlob",
//        @"RCTImage",
//        @"RCTLinking",
//        @"RCTNetwork",
//        @"RCTSettings",
//        @"RCTTypeSafety",
//        @"RCTVibration",
    ];
    [frameworkNames enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [self updateFramework:obj finishBlock:^(NSString *name) {
            [bridge reload];
        }];
    }];
    
    rootView.backgroundColor = [[UIColor alloc] initWithRed:1.0f green:1.0f blue:1.0f alpha:1];
    RNCViewController *rootViewController = [RNCViewController new];
    rootViewController.view = rootView;
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.rootViewController = rootViewController;
    [self.window makeKeyAndVisible];
    
    return YES;
}

#if __has_include(<UMModuleRegistryAdapter.h>)
- (NSArray<id<RCTBridgeModule>> *)extraModulesForBridge:(RCTBridge *)bridge {
    NSArray<id<RCTBridgeModule>> *extraModules = [_moduleRegistryAdapter extraModulesForBridge:bridge];
    // If you'd like to export some custom RCTBridgeModules that are not Expo modules, add them here!
    return extraModules;
}
#endif

- (NSURL *)sourceURLForBridge:(RCTBridge *)bridge {
#if __has_include(<UMModuleRegistryAdapter.h>)
    return [NSURL URLWithString:[[[[NSBundle mainBundle] URLForResource:@"ExpoProject" withExtension:@"bundle"] relativePath] stringByAppendingPathComponent:@"41.0.1/main.jsbundle"]];
#else
    return [NSURL URLWithString:[[[[NSBundle mainBundle] URLForResource:@"AwesomeProject" withExtension:@"bundle"] relativePath] stringByAppendingPathComponent:@"0.63.4/main.jsbundle"]];
#endif
}


- (void)signatureWithFields:(QCloudSignatureFields *)fileds request:(QCloudBizHTTPRequest *)request urlRequest:(NSMutableURLRequest *)urlRequst compelete:(QCloudHTTPAuthentationContinueBlock)continueBlock {
    QCloudCredential* credential = [QCloudCredential new];
    // SECRETID和SECRETKEY请登录访问管理控制台进行查看和管理
    credential.secretID = @"AKID1rRloa7NM4UfZCZgX7QTFkzxf6G9m9F5"; // 永久密钥 SecretId
    credential.secretKey = @"bvykFTR8YhZAUXNwEFzRcWAXdS1IJ2Ug"; // 永久密钥 SecretKey
    // 使用永久密钥计算签名
    QCloudAuthentationV5Creator* creator = [[QCloudAuthentationV5Creator alloc]
                                            initWithCredential:credential];
    QCloudSignature* signature = [creator signatureForData:urlRequst];
    continueBlock(signature, nil);
}

@end
